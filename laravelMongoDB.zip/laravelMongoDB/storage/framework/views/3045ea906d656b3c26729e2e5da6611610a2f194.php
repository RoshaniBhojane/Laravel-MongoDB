<!DOCTYPE html>
<html>
<head>
    <title>Student Details Laravel+MongoDB</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>">
</head>
<body>


<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</body>
</html><?php /**PATH C:\xampp\htdocs\laravelMongoDB\resources\views/students/layout.blade.php ENDPATH**/ ?>