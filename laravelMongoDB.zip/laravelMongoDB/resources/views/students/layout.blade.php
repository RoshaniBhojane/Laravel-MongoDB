<!DOCTYPE html>
<html>
<head>
    <title>Student Details Laravel+MongoDB</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/styles.css') }}">
</head>
<body>


<div class="container">
    @yield('content')
</div>


</body>
</html>