<?php

namespace App\Console\Commands;

use App\Counts;
use App\Students;
use Illuminate\Console\Command;

class CountStudents extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'job:count';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        $total = Students::count();
        $total_counts = new Counts();
        $total_counts->total_number_of_students = $total;
        $total_counts->save();      
    }
}
