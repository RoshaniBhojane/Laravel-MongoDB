<?php


namespace App;


use Jenssegers\Mongodb\Eloquent\Model as Eloquent;


class Counts extends Eloquent
{
	protected $connection = 'mongodb';
	protected $collection = 'total_counts';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'total_number_of_students'
    ];

}