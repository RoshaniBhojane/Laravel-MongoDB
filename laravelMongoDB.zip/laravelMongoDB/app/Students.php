<?php


namespace App;


use Jenssegers\Mongodb\Eloquent\Model as Eloquent;


class Students extends Eloquent
{
	protected $connection = 'mongodb';
	protected $collection = 'students';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'Student_Name', 'Phone_Number', 'Address'
    ];

}