<?php


namespace App\Http\Controllers;


use App\Students;
use Illuminate\Http\Request;


class StudentsController extends Controller
{
    public function index()
    {
        $students = Students::all();
        return view('students.index',compact('students'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        return view('students.create');
    }

    function csvToArray($filename = '', $delimiter = ',')
    {
        if (!file_exists($filename) || !is_readable($filename))
            return false;

        $header = null;
        $data = array();
        if (($handle = fopen($filename, 'r')) !== false)
        {
            while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
            {
                if (!$header)
                    $header = $row;
                else
                    $data[] = array_combine($header, $row);
            }
            fclose($handle);
        }

        return $data;
    }

    public function store(Request $request)
    {
        if ($request->input('submit') != null )
        {

            $file = $request->file('file');

            $filename = time().'_'.$file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $tempPath = $file->getRealPath();
            $fileSize = $file->getSize();
            $mimeType = $file->getMimeType();

            $valid_extension = array("csv");
            $maxFileSize = 2097152;
            $location = public_path('uploads');
            if(in_array(strtolower($extension),$valid_extension))
            {
                if($fileSize <= $maxFileSize)
                {
                    $file->move($location,$filename);
                    $filepath = $location.'/'.$filename;
                    $studentArr = $this->csvToArray($filepath);
                    $date = '';
                    for ($i = 0; $i < count($studentArr); $i ++)
                    {
                        $data[] = [
                            'Student_Name' => $studentArr[$i]['Student_Name'],
                            'Phone_Number' => $studentArr[$i]['Phone_Number'],
                            'Address' => $studentArr[$i]['Address'],
                        ];
                        Students::firstOrCreate($studentArr[$i]);
                    }
                    unlink($filepath);
                    return redirect()->route('students.index')
                                    ->with('success','Students created successfully.');
                }
            }
        }
    }

}